#include <iostream>
using namespace std;
int main()
{
    cout<<"\t Subject \t\t\t\t      Marks "<<"\n";
    cout<<"\tBig Data Technologies  \t\t  90 "<<"\n";
    cout<<"\tStatistic \t\t\t\t      77 "<<"\n";
    cout<<"\tAdvanced Data Structures \t  69 ";
    return 0;
}
